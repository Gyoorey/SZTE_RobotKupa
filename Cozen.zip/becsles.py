import csv


def index_exists(row, index):
    return index < len(row)


def where(filename):
    with open(filename) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=';')
        next(csv_reader)
        next(csv_reader)
        negative_count = 0
        positive_count = 0

        for row in csv_reader:
            if index_exists(row, 0):
                if row[0] != ' ' or row[0] != '':
                    if row[0].__contains__(':'):
                        colon_count = row[0].count(':')
                        if colon_count == 1:
                            sensor1 = row[0].split(':')
                            pwm1 = sensor1[1]
                        else:
                            next(csv_reader)
                    else:
                        next(csv_reader)
                else:
                    next(csv_reader)
            else:
                next(csv_reader)

            if index_exists(row, 1):
                if row[1] != ' ' or row[1] != '':
                    if row[1].__contains__(':'):
                        colon_count = row[1].count(':')
                        if colon_count == 1:
                            sensor2 = row[1].split(':')
                            pwm2 = sensor2[1]
                        else:
                            next(csv_reader)
                    else:
                        next(csv_reader)
                else:
                    next(csv_reader)
            # else:
            #     next(csv_reader)

            if (pwm1 == '' or pwm1 == ' ') and (pwm2 != '' or pwm2 != ' '):
                pwm1 = pwm2
            elif (pwm1 != '' or pwm1 != ' ') and (pwm2 == '' or pwm2 == ' '):
                pwm2 = pwm1
            elif (pwm1 and pwm2) == '' or (pwm1 and pwm2) == ' ':
                next(csv_reader)

            if (float(pwm1) and float(pwm2)) <= 0:

                negative_count += 1
            else:

                positive_count += 1
            # break
        if negative_count > positive_count:
            print(f'A súly a robot hátsó felén van')
            print(f'{negative_count}, {positive_count}')
        elif negative_count < positive_count:
            print(f'A súly a robot elején van')
            print(f'{negative_count}, {positive_count}')
        else:

            print("nincs súly")
            # print(f'{negative_count}, {positive_count}')


if __name__ == '__main__':
    print("Add meg a fájl nevét: ")
    fajlnev = input()
    where(fajlnev)
