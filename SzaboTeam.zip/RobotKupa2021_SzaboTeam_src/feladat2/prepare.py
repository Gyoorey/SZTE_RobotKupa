"""SZTE Robot Kupa 2021
@author SzaboTeam
@date 2022.01.22.
"""

import argparse
import os
import pandas as pd
import numpy as np


def prepare_data(df, filename):
    original_column = str(df.columns.values[0])

    # Add time variable (time is increasing by 5 ms)
    df.insert(loc=0, column='time', value=range(0, len(df)*5, 5))

    # Add target variable (label)
    num_list = [int(s) for s in filename.split('_') if s.isdigit()]  # read distance value from the filename
    if len(num_list) == 2:
        target = pd.DataFrame((num_list[0] + num_list[1] / 100) * np.ones(df.shape[0]))
        if "_n_" in filenames[0]:
            target = -target
        df.insert(loc=0, column='target', value=target)  # 'target' is the first column

    # Convert to string (needed for split)
    df = df.astype(str)

    # Take rows with 10 values (measures) only
    df = df[df[original_column].apply(lambda x: len(x.split('; ')) == 10)]
    df = df[df[original_column].apply(lambda x: len(x.split(': ')) == 11)]
    df = df[df[original_column].apply(lambda x: len(x.split('.')) <= 11)]
    # print(df.shape)

    # Rename second column as 'pwm1' (here it contains all variables in strings)
    # e.g. "1: -2.48; 2: -2.48; 3: 0; 4: 0; 5: 488; 6: 88; 7: 15568; 8: 1003; 9: -59; 10: 471"
    df = df.rename(columns={original_column: "pwm1"})
    temp_df = df.copy()

    # Get values from strings
    df.pwm1 = [n.split("; ")[0].split(": ")[1] for n in temp_df.pwm1]  # get values of first variable
    df['pwm2'] = [n.split("; ")[1].split(": ")[1] for n in temp_df.pwm1]
    df['pulseright'] = [n.split("; ")[2].split(": ")[1] for n in temp_df.pwm1]
    df['pulseleft'] = [n.split("; ")[3].split(": ")[1] for n in temp_df.pwm1]
    df['ax'] = [n.split("; ")[4].split(": ")[1] for n in temp_df.pwm1]
    df['ay'] = [n.split("; ")[5].split(": ")[1] for n in temp_df.pwm1]
    df['az'] = [n.split("; ")[6].split(": ")[1] for n in temp_df.pwm1]
    df['gx'] = [n.split("; ")[7].split(": ")[1] for n in temp_df.pwm1]
    df['gy'] = [n.split("; ")[8].split(": ")[1] for n in temp_df.pwm1]
    df['gz'] = [n.split("; ")[9].split(": ")[1] for n in temp_df.pwm1]

    # Transform the non-numeric values into NaN
    df['pwm1'] = pd.to_numeric(df['pwm1'], errors='coerce')
    df['pwm2'] = pd.to_numeric(df['pwm2'], errors='coerce')
    df['pulseright'] = pd.to_numeric(df['pulseright'], errors='coerce')
    df['pulseleft'] = pd.to_numeric(df['pulseleft'], errors='coerce')
    df['ax'] = pd.to_numeric(df['ax'], errors='coerce')
    df['ay'] = pd.to_numeric(df['ay'], errors='coerce')
    df['az'] = pd.to_numeric(df['az'], errors='coerce')
    df['gx'] = pd.to_numeric(df['gx'], errors='coerce')
    df['gy'] = pd.to_numeric(df['gy'], errors='coerce')
    df['gz'] = pd.to_numeric(df['gz'], errors='coerce')

    # Drop rows which has NaN values
    df = df.dropna(axis=0)

    print(df.shape)

    return df


if __name__ == "__main__":
    # Construct the argument parser and add the arguments to the parser
    ap = argparse.ArgumentParser()
    ap.add_argument("-d", "--dir", required=True, help="Give the directory of multiple data series")
    args = vars(ap.parse_args())

    # List all files from the directory
    # e.g. dir_data = "50g_n"
    dir_data = args['dir']
    filenames = os.listdir(dir_data)

    result_path = dir_data + "_prepared"
    os.makedirs(result_path, exist_ok=True)

    # Prepare all files
    for filename in filenames:
        df = pd.read_csv(dir_data + "/" + filename, encoding='latin-1')  # (n_60_05_50g -> 2271.)
        df = prepare_data(df, filename)
        df.to_csv(result_path + "/" + filename, index=False)


# USE CASE
# python prepare.py -d 30g_n
# python prepare.py -d test_30

