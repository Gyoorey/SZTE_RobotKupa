"""SZTE Robot Kupa 2021
@author SzaboTeam
@date 2022.01.22.
"""

import argparse
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def plot_data(df, file_name, save = False):
    fig, ax = plt.subplots(8)

    g0 = sns.lineplot(data=df, x='time', y='pwm1', ax=ax[0])
    g1 = sns.lineplot(data=df, x='time', y='pulseright', ax=ax[1])
    g2 = sns.lineplot(data=df, x='time', y='ax', ax=ax[2])
    g3 = sns.lineplot(data=df, x='time', y='ay', ax=ax[3])
    g4 = sns.lineplot(data=df, x='time', y='az', ax=ax[4])
    g5 = sns.lineplot(data=df, x='time', y='gx', ax=ax[5])
    g6 = sns.lineplot(data=df, x='time', y='gy', ax=ax[6])
    g7 = sns.lineplot(data=df, x='time', y='gz', ax=ax[7])
    # g8 = sns.lineplot(data=df, x='time', y='angle', ax=ax[8])

    g7.set_xlabel('time (ms)')

    g0.set(xticklabels=[])  # remove the tick labels
    g1.set(xticklabels=[])
    g2.set(xticklabels=[])
    g3.set(xticklabels=[])
    g4.set(xticklabels=[])
    g5.set(xticklabels=[])
    g6.set(xticklabels=[])
    # g7.set(xticklabels=[])  #
    g0.set(xlabel=None)  # remove the axis label
    g1.set(xlabel=None)
    g2.set(xlabel=None)
    g3.set(xlabel=None)
    g4.set(xlabel=None)
    g5.set(xlabel=None)
    g6.set(xlabel=None)
    # g7.set(xlabel=None)  #
    g0.set_ylabel('pwm1', fontsize=8)
    g1.set_ylabel('pulseright', fontsize=8)
    g2.set_ylabel('ax', fontsize=8)
    g3.set_ylabel('ay', fontsize=8)
    g4.set_ylabel('az', fontsize=8)
    g5.set_ylabel('gx', fontsize=8)
    g6.set_ylabel('gy', fontsize=8)
    g7.set_ylabel('gz', fontsize=8)
    # g8.set_ylabel('angle', fontsize=8)
    g0.set_yticklabels(g0.get_yticks(), size=8)
    g1.set_yticklabels(g0.get_yticks(), size=8)
    g2.set_yticklabels(g0.get_yticks(), size=8)
    g3.set_yticklabels(g0.get_yticks(), size=8)
    g4.set_yticklabels(g0.get_yticks(), size=8)
    g5.set_yticklabels(g0.get_yticks(), size=8)
    g6.set_yticklabels(g0.get_yticks(), size=8)
    g7.set_yticklabels(g0.get_yticks(), size=8)
    # g8.set_yticklabels(g0.get_yticks(), size=8)

    plt.show()

    if save:
        fig.savefig(file_name.split("/")[1].split(".")[0])


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument("-f", "--filename", required=True, help="Give the filename of the data")
    ap.add_argument("-s", "--save", required=False, help="Save image: y/n?")
    args = vars(ap.parse_args())

    file_name = args['filename']
    save = args['save']
    # file_name = "30g_n_prepared/Robot_n_20_92_30g.csv"
    df = pd.read_csv(file_name)

    plot_data(df, file_name, save)
