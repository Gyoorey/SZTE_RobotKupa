"""SZTE Robot Kupa 2021
@author SzaboTeam
@date 2022.02.03.
"""

import numpy as np
import pandas as pd
import os
import argparse
import matplotlib.pyplot as plt


def get_features(dir_list):
    features = np.array(0)

    for i, dir_data in enumerate(dir_list):
        filenames = os.listdir(dir_data)

        for j, filename in enumerate(filenames):
            dataframe = pd.read_csv(dir_data + "/" + filename)

            if 'suly_nelkul' in filename:
                target_value = 0
            else:
                target_value = dataframe['target'][0]

            # Select features
            dataframe = dataframe[['pwm1', 'pulseright']]

            # Remove outliers
            # IQR
            Q1 = np.percentile(dataframe['pulseright'], 25, interpolation='midpoint')
            Q3 = np.percentile(dataframe['pulseright'], 75, interpolation='midpoint')
            IQR = Q3 - Q1
            # Upper bound
            upper = np.where(dataframe['pulseright'] >= (Q3 + 3 * IQR))
            # Lower bound
            lower = np.where(dataframe['pulseright'] <= (Q1 - 3 * IQR))
            # Remove
            dataframe.drop(upper[0], inplace=True)
            dataframe.drop(lower[0], inplace=True)
            dataframe.reset_index(drop=True, inplace=True)

            # Drop first x rows
            dataframe.drop([n for n in range(0, 100)], inplace=True)
            dataframe.reset_index(drop=True, inplace=True)

            # Truncate to first x rows
            num_of_rows = min(1300, dataframe.shape[0])
            dataframe.drop([n for n in range(num_of_rows, dataframe.shape[0])], inplace=True)
            # print(dataframe.shape)

            # Collect features
            pulseright_sum = dataframe['pulseright'].sum()
            point = np.array([target_value, pulseright_sum])

            # pulseright_centered = dataframe['pulseright'] - dataframe['pulseright'].mean()
            # point = np.array([target_value, pulseright_centered])

            if i == 0 and j == 0:
                features = point
            else:
                features = np.vstack((features, point))

    features = np.sort(features, axis=0)

    return features


def get_functions_30(features):
    y = features.transpose()[0]  # distance of the weight
    x = features.transpose()[1]  # used feature (sum of 'pulseright')

    # Get first and last three element
    x_boundary = x
    y_boundary = y
    x_boundary = np.delete(x_boundary, (range(3, len(x_boundary) - 3)))
    y_boundary = np.delete(y_boundary, (range(3, len(y_boundary) - 3)))

    # Delete first and last two element
    x = np.delete(x, (range(0, 2)), axis=0)
    y = np.delete(y, (range(0, 2)), axis=0)
    x = np.delete(x, (range(len(x) - 2, len(x))), axis=0)
    y = np.delete(y, (range(len(y) - 2, len(y))), axis=0)

    # Fit polynomial function
    coef = np.polyfit(x, y, 3)
    poly_function = np.poly1d(coef)
    x_ill = np.arange(min(x_boundary), max(x_boundary), 1)

    # Fit linear function (first 3 points)
    coef = np.polyfit(x_boundary[:3], y_boundary[:3], 1)
    lin_function = np.poly1d(coef)

    # Fit linear function (last 3 points)
    coef = np.polyfit(x_boundary[3:len(x_boundary)], y_boundary[3:len(y_boundary)], 1)
    lin_function2 = np.poly1d(coef)

    # Plot
    # plt.figure()
    # plt.plot(x, y, "b.")
    # plt.plot(x_boundary, y_boundary, "r.")
    # plt.plot(x_ill, poly_function(x_ill), "b-")
    # plt.plot(x_ill, lin_function(x_ill), "r-")
    # plt.plot(x_ill, lin_function2(x_ill), "r-")
    # plt.ylim(-90, 80)
    # plt.show()

    return poly_function, lin_function, lin_function2


def get_functions_50(features):
    y = features.transpose()[0]  # distance of the weight
    x = features.transpose()[1]  # used feature (sum of 'pulseright')

    # Fit polynomial function (first six element)
    coef = np.polyfit(x[:6], y[:6], 2)
    poly_function1 = np.poly1d(coef)
    x_ill = np.arange(min(x), max(x), 1)

    # Fit linear function (last six element)
    coef = np.polyfit(x[7:len(x)], y[7:len(y)], 2)
    poly_function2 = np.poly1d(coef)

    # Plot
    # plt.figure()
    # plt.plot(x, y, "b.")
    # plt.plot(x_ill, poly_function1(x_ill), "b-")
    # plt.plot(x_ill, poly_function2(x_ill), "r-")
    # plt.ylim(-90, 80)
    # plt.show()

    return poly_function1, poly_function2


def get_test_value(directory):
    filenames = os.listdir(directory)
    filename_n_value = list()

    for j, filename in enumerate(filenames):
        dataframe = pd.read_csv(directory + "/" + filename)

        # Select features
        dataframe = dataframe[['pwm1', 'pulseright']]

        # Remove outliers
        # IQR
        Q1 = np.percentile(dataframe['pulseright'], 25, interpolation='midpoint')
        Q3 = np.percentile(dataframe['pulseright'], 75, interpolation='midpoint')
        IQR = Q3 - Q1
        # Upper bound
        upper = np.where(dataframe['pulseright'] >= (Q3 + 3 * IQR))
        # Lower bound
        lower = np.where(dataframe['pulseright'] <= (Q1 - 3 * IQR))
        # Remove
        dataframe.drop(upper[0], inplace=True)
        dataframe.drop(lower[0], inplace=True)
        dataframe.reset_index(drop=True, inplace=True)

        # Drop first x rows
        dataframe.drop([n for n in range(0, 100)], inplace=True)
        dataframe.reset_index(drop=True, inplace=True)

        # Truncate to first x rows
        num_of_rows = min(1300, dataframe.shape[0])
        dataframe.drop([n for n in range(num_of_rows, dataframe.shape[0])], inplace=True)

        # Calculate test value
        pulseright_sum = dataframe['pulseright'].sum()
        obj = (filename, pulseright_sum)

        filename_n_value.append(obj)

    return filename_n_value


if __name__ == "__main__":
    # Construct the argument parser and add the arguments to the parser
    ap = argparse.ArgumentParser()
    ap.add_argument("-d", "--dir", required=True, help="Give the directory of test samples")
    ap.add_argument("-w", "--weight", required=True, help="50/30")
    args = vars(ap.parse_args())

    # directory = "test_prepared"
    # weight = 30
    directory = args['dir']
    weight = int(args['weight'])

    test_value_list = get_test_value(directory)
    print(test_value_list)

    # test_value_list.append(('test_random', 53))
    for elem in test_value_list:
        test_filename = elem[0]
        test_value = elem[1]

        if weight == 30:
            dir_list = ['30g_n_prepared', 'suly_nelkul_prepared', '30g_p_prepared']
            features = get_features(dir_list)
            poly_function, lin_function, lin_function2 = get_functions_30(features)

            if features[2][1] <= test_value <= features[len(features) - 3][1]:
                print("The predicted value for {0:} is: {1:0.3f} mm.".format(test_filename, poly_function(test_value)))
            elif test_value < features[2][1]:
                print("The predicted value for {0:} is: {1:0.3f} mm.".format(test_filename, lin_function(test_value)))
            elif features[len(features) - 3][1] < test_value:
                print("The predicted value for {0:} is: {1:0.3f} mm.".format(test_filename, lin_function2(test_value)))

        elif weight == 50:
            dir_list = ['50g_n_prepared', 'suly_nelkul_prepared', '50g_p_prepared']
            features = get_features(dir_list)
            poly_function1, poly_function2 = get_functions_50(features)

            if test_value < features[7][1]:
                print("The predicted value for {0:} is: {1:0.3f} mm.".format(test_filename, poly_function1(test_value)))
            elif features[7][1] <= test_value:
                print("The predicted value for {0:} is: {1:0.3f} mm.".format(test_filename, poly_function2(test_value)))


# USE CASE
# python -W ignore predict.py -d test_30_prepared -w 30
